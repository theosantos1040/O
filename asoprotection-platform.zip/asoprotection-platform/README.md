# Aso Protection Platform

Projeto demo pronto para Git e deploy em hosts Node como Railway, Render, Fly.io ou VPS.

## O que está implementado
- cadastro e login por e-mail
- trial Pro por 10 dias
- geração de `siteKey` e `secretKey`
- página admin separada em `/asopartedeadm`
- senha de admin **somente no backend** via `ADMIN_PASSWORD`
- painel com:
  - quantidade de requisições por key
  - bloqueios por key
  - eventos recentes
  - IPs bloqueados
  - sessões suspeitas
- CAPTCHA estilo reCAPTCHA com:
  - logo Aso maior
  - seta animada
  - desafio de letras
  - desafio de matemática
  - áudio
- ingestão de telemetria (`/api/intake`)
- verificação server-to-server (`/api/verify`)
- bloqueios de aplicação para:
  - padrões repetitivos
  - sinais de SQLi / XSS / RCE
  - user-agents de automação
  - cabeçalhos suspeitos
  - geoblocking opcional por país / ASN / CIDR se o proxy upstream fornecer os headers

## O que NÃO é possível prometer neste projeto sozinho
Este projeto **não substitui** uma rede global tipo Cloudflare. Itens abaixo exigem provedores/infra adicionais e aparecem aqui como pontos de integração, não como equivalentes completos:
- mitigação Tbps em Layer 3/4
- Anycast global
- CDN com centenas de cidades
- zero-day managed rules em escala global
- JA3/TLS fingerprint sem proxy upstream específico
- Zero Trust / IdP corporativo completo
- SIEM enterprise / log streaming gerenciado

## Segurança do admin
A senha **não deve** ficar no HTML, JS ou Git.
Use variável de ambiente:

- `ADMIN_PASSWORD`
- `APP_SECRET`

Também configure:
- `ADMIN_EMAIL`
- `APP_URL`

## Deploy rápido
1. envie os arquivos para um repositório Git
2. conecte no seu host Node
3. configure as variáveis de ambiente
4. execute `npm install`
5. execute `npm start`

## Variáveis de ambiente
Veja `.env.example`.

## Rotas principais
- `/` painel do cliente
- `/asopartedeadm` painel admin
- `/api/auth/register`
- `/api/auth/login`
- `/api/keys/create`
- `/api/admin/keys/create`
- `/api/intake`
- `/api/verify`
- `/api/widget.js`

## Exemplo Java
Veja `examples/ShieldVerifier.java`.

## Observações de produção
Para subir o nível real:
- usar Postgres/Redis em vez de arquivo JSON
- mover bloqueios quentes para Redis
- colocar proxy/WAF na frente
- adicionar MFA / OIDC
- ativar logs centralizados
