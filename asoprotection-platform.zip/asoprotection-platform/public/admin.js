
(() => {
  const $ = (id) => document.getElementById(id);

  async function api(path, method = 'GET', body) {
    const opts = {
      method,
      headers: { 'Accept': 'application/json' },
      credentials: 'same-origin'
    };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(path, opts);
    const data = await res.json().catch(() => ({ ok: false, message: 'Resposta inválida.' }));
    if (!res.ok) throw new Error(data.message || 'Erro');
    return data;
  }

  function setStatus(id, text, color = '') {
    const el = $(id);
    el.textContent = text;
    el.style.color = color || '';
  }

  async function renderAdmin() {
    const data = await api('/api/admin/stats');
    $('loginCard').classList.add('hidden');
    $('adminPanel').classList.remove('hidden');

    const usersT = $('adminUsers');
    usersT.innerHTML = '';
    data.users.forEach(u => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${u.email}</td><td>${u.plan}</td><td>${new Date(u.trialEndsAt).toLocaleString('pt-BR')}</td>`;
      usersT.appendChild(tr);
    });

    const auditT = $('adminAudit');
    auditT.innerHTML = '';
    data.audit.forEach(a => {
      const detail = [a.email || '', a.project || '', a.domain || '', a.by || ''].filter(Boolean).join(' · ');
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${new Date(a.createdAt).toLocaleString('pt-BR')}</td><td>${a.type}</td><td>${detail}</td>`;
      auditT.appendChild(tr);
    });
  }

  async function loginAdmin() {
    try {
      setStatus('adminLoginStatus', 'Entrando...');
      await api('/api/admin/login', 'POST', { password: $('adminPassword').value });
      await renderAdmin();
    } catch (err) {
      setStatus('adminLoginStatus', err.message, '#c53b3b');
    }
  }

  async function logoutAdmin() {
    await api('/api/admin/logout', 'POST', {});
    location.reload();
  }

  async function generateAdminKey() {
    try {
      setStatus('adminGenerateStatus', 'Gerando key...');
      const data = await api('/api/admin/keys/create', 'POST', {
        email: $('targetEmail').value.trim(),
        project: $('targetProject').value.trim(),
        domain: $('targetDomain').value.trim()
      });
      $('adminOut').textContent = JSON.stringify(data.key, null, 2);
      setStatus('adminGenerateStatus', 'Key pro criada.', '#1f8a5b');
      await renderAdmin();
    } catch (err) {
      setStatus('adminGenerateStatus', err.message, '#c53b3b');
    }
  }

  async function bootstrapAdmin() {
    try {
      const data = await api('/api/admin/me');
      if (data.ok) await renderAdmin();
    } catch (_) {}
  }

  $('adminLoginBtn').addEventListener('click', loginAdmin);
  $('adminLogoutBtn').addEventListener('click', logoutAdmin);
  $('adminGenerateBtn').addEventListener('click', generateAdminKey);

  bootstrapAdmin();
})();
